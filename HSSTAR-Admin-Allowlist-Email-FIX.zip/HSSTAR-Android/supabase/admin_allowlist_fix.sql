-- HSSTAR admin allowlist policy repair. Run in Supabase SQL Editor.
-- This does not change passwords, users, videos, or storage.
alter table public.admin_users enable row level security;
drop policy if exists "Admins can read their own admin record" on public.admin_users;
create policy "Admins can read their own admin record"
on public.admin_users for select to authenticated
using (lower(trim(email)) = lower(trim(coalesce(auth.jwt() ->> 'email', ''))));

-- Ensure the intended admin email is present (safe to run more than once).
insert into public.admin_users(email)
values ('attackersazan2m@gmail.com')
on conflict (email) do nothing;
