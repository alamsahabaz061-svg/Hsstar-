-- HSSTAR database and storage setup
-- 1) Create your admin user in Supabase Dashboard > Authentication > Users.
-- 2) Replace the email below with that exact admin email, then run this SQL.

create table if not exists public.admin_users (
  email text primary key,
  created_at timestamptz not null default now()
);

alter table public.admin_users enable row level security;

drop policy if exists "Admins can read their own admin record" on public.admin_users;
create policy "Admins can read their own admin record"
on public.admin_users for select to authenticated
using (lower(email) = lower(coalesce(auth.jwt() ->> 'email', '')));

create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  category text not null default 'Other',
  description text not null default '',
  video_url text not null,
  thumbnail_url text,
  is_published boolean not null default true,
  created_at timestamptz not null default now()
);

create index if not exists videos_published_created_idx
on public.videos (is_published, created_at desc);

alter table public.videos enable row level security;

drop policy if exists "Anyone can view published videos" on public.videos;
create policy "Anyone can view published videos"
on public.videos for select to anon, authenticated
using (is_published = true);

drop policy if exists "Admins can read all videos" on public.videos;
create policy "Admins can read all videos"
on public.videos for select to authenticated
using (
  exists (
    select 1 from public.admin_users a
    where lower(a.email) = lower(coalesce(auth.jwt() ->> 'email', ''))
  )
);

drop policy if exists "Admins can add videos" on public.videos;
create policy "Admins can add videos"
on public.videos for insert to authenticated
with check (
  exists (
    select 1 from public.admin_users a
    where lower(a.email) = lower(coalesce(auth.jwt() ->> 'email', ''))
  )
);

drop policy if exists "Admins can update videos" on public.videos;
create policy "Admins can update videos"
on public.videos for update to authenticated
using (
  exists (select 1 from public.admin_users a where lower(a.email) = lower(coalesce(auth.jwt() ->> 'email', '')))
)
with check (
  exists (select 1 from public.admin_users a where lower(a.email) = lower(coalesce(auth.jwt() ->> 'email', '')))
);

drop policy if exists "Admins can delete videos" on public.videos;
create policy "Admins can delete videos"
on public.videos for delete to authenticated
using (
  exists (select 1 from public.admin_users a where lower(a.email) = lower(coalesce(auth.jwt() ->> 'email', '')))
);

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('hsstar-videos', 'hsstar-videos', true, 2147483648, array['video/mp4'])
on conflict (id) do update set public = true, file_size_limit = 2147483648,
  allowed_mime_types = array['video/mp4'];

drop policy if exists "HSSTAR admins upload videos" on storage.objects;
create policy "HSSTAR admins upload videos"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'hsstar-videos'
  and exists (
    select 1 from public.admin_users a
    where lower(a.email) = lower(coalesce(auth.jwt() ->> 'email', ''))
  )
);

drop policy if exists "HSSTAR admins update video objects" on storage.objects;
create policy "HSSTAR admins update video objects"
on storage.objects for update to authenticated
using (
  bucket_id = 'hsstar-videos'
  and exists (select 1 from public.admin_users a where lower(a.email) = lower(coalesce(auth.jwt() ->> 'email', '')))
)
with check (
  bucket_id = 'hsstar-videos'
  and exists (select 1 from public.admin_users a where lower(a.email) = lower(coalesce(auth.jwt() ->> 'email', '')))
);

drop policy if exists "HSSTAR admins delete video objects" on storage.objects;
create policy "HSSTAR admins delete video objects"
on storage.objects for delete to authenticated
using (
  bucket_id = 'hsstar-videos'
  and exists (select 1 from public.admin_users a where lower(a.email) = lower(coalesce(auth.jwt() ->> 'email', '')))
);

-- Run after creating the admin user in Authentication > Users:
-- insert into public.admin_users(email) values ('YOUR_ADMIN_EMAIL');
