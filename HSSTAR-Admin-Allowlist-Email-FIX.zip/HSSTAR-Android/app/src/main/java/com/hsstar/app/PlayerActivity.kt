package com.hsstar.app

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : Activity() {
    private var player: ExoPlayer? = null
    private var videoId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        videoId = intent.getStringExtra("video_id").orEmpty()
        val frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val playerView = PlayerView(this).apply {
            useController = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
        }
        frame.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)
        val url = intent.getStringExtra("video_url") ?: run { finish(); return }
        title = intent.getStringExtra("title") ?: "HSSTAR Player"
        val resumeAt = intent.getLongExtra("resume_position", 0L)
        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            exo.setMediaItem(MediaItem.fromUri(url))
            exo.addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    Toast.makeText(this@PlayerActivity, "Playback error: ${error.errorCodeName}", Toast.LENGTH_LONG).show()
                }
            })
            exo.prepare()
            if (resumeAt > 0L) exo.seekTo(resumeAt)
            exo.playWhenReady = true
        }
    }

    override fun onStop() {
        savePosition()
        super.onStop()
        player?.pause()
    }

    private fun savePosition() {
        val exo = player ?: return
        if (videoId.isNotBlank()) {
            val position = if (exo.duration > 0 && exo.currentPosition >= exo.duration - 10_000) 0L else exo.currentPosition
            getSharedPreferences("hsstar_watch", MODE_PRIVATE).edit().putLong("position_$videoId", position).apply()
        }
    }

    override fun onDestroy() {
        savePosition()
        player?.release()
        player = null
        super.onDestroy()
    }
}
