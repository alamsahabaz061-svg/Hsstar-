# HSSTAR Android Streaming App

Native Android starter app branded **HSSTAR**, using the user's supplied star artwork as the launcher icon and supplied HSSTAR wordmark banner. The app uses Supabase for its video catalogue, admin authentication and MP4 storage, and AndroidX Media3 for playback.

## Features in this version

- HSSTAR star launcher icon and HSSTAR banner artwork.
- Dark OTT-style home screen with a featured hero panel.
- Search by title, description or category.
- Horizontal poster rails for Trending Now and Latest Movies & Shows.
- Top 10 presentation (currently newest 10 published uploads; view-based ranking is not implemented).
- Movies, Web Series, Short Films and Other category filters.
- Continue Watching rail with locally saved playback position and resume support.
- Media3/ExoPlayer playback.
- Supabase email/password admin sign-in with an admin allowlist check.
- Admin dashboard to upload MP4s, hide published titles, and delete catalogue records.
- Optional poster image URL when uploading a title.
- GitHub Actions workflow to build a debug APK and upload it as an artifact.

## 1. Supabase setup (required once)

Configured project URL: `https://obnyuvexzctpwtbjtgcz.supabase.co`.

The Android app contains only the Supabase publishable client key. Never add a `service_role` or secret key to the APK or GitHub repository.

1. Open Supabase Dashboard → Authentication → Users and create the admin user with an email and password.
2. Open SQL Editor and run the complete `supabase/setup.sql` file.
3. Add the exact admin email created in step 1 by running:

   ```sql
   insert into public.admin_users(email) values ('YOUR_ADMIN_EMAIL');
   ```

4. Confirm the `hsstar-videos` Storage bucket exists. The SQL creates a public-read bucket for direct playback. Only allowlisted authenticated admins can upload video files.

**Important:** this starter uses public video URLs. Only publish content you own or are licensed to distribute. Public bucket URLs are not DRM-protected.

## 2. Build APK with GitHub Actions

1. Download and extract this project ZIP on a computer or Android file manager.
2. Upload the *contents* of the `HSSTAR-Android` folder into the root of a GitHub repository. Do not upload the ZIP as a nested file.
3. Confirm `.github/workflows/android.yml` is in the repository root's `.github/workflows/` folder and the branch is `main`.
4. Open GitHub → Actions → **Build HSSTAR Android APK** → **Run workflow**.
5. When the workflow succeeds, open the run summary and download the `HSSTAR-debug-apk` artifact. Extract that artifact ZIP to get `app-debug.apk`, then install it on Android.

The workflow installs Android command-line tools into a clean temporary SDK directory and does not use the runner's preinstalled `sdkmanager` (avoids the previously encountered “Wrong version in preinstalled sdkmanager” issue).

## 3. Admin upload and catalogue management

1. Open HSSTAR and tap **ADMIN**.
2. Sign in using the Supabase admin email/password added to `public.admin_users`.
3. Choose **Upload new video**, select an MP4, enter title/category/description, and optionally enter a poster image HTTPS URL.
4. Keep the app open while upload is in progress. It uploads the MP4 to Supabase Storage and then creates the catalogue row.
5. Use **Manage catalogue** to hide a title from the public catalogue or delete its database record. Deleting the record does not delete the underlying Storage object; clean up unused files in Supabase Storage manually.

Use MP4/H.264 video with AAC audio for broad Android compatibility. Large uploads can fail on unstable mobile connections; resumable uploads/background uploads are not implemented.

## 4. Project details

- Application ID: `com.hsstar.app`
- App label: `HSSTAR`
- Minimum Android: 7.0 (API 24)
- Compile/target SDK: 35
- JDK: 17
- Gradle: 8.9

## 5. Production limitations

This is an improved functional starter, not a production-scale OTT service. It does not include subscription/payment processing, DRM, offline downloads, adaptive bitrate transcoding, resumable/background uploads, analytics-based trending rankings, or a separate web admin dashboard. The “Top 10” rail currently displays the latest 10 published titles rather than popularity-ranked titles. Continue Watching stores playback position on the device, not in a cross-device user account.
