package com.hsstar.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okio.BufferedSink
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URL
import java.util.UUID
import java.util.concurrent.Executors

private const val BG = 0xFF070B18.toInt()
private const val PANEL = 0xFF111A30.toInt()
private const val BLUE = 0xFF168BFF.toInt()
private const val MUTED = 0xFF9EABC4.toInt()
private const val GOLD = 0xFFFFB547.toInt()
private val http = OkHttpClient.Builder().build()
private val io = Executors.newSingleThreadExecutor()

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var allVideos = JSONArray()
    private var selectedCategory = "All"
    private var searchQuery = ""
    private var adminToken: String? = null
    private var pendingVideoUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        buildScreen()
        loadVideos()
    }

    private fun buildScreen() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(15), dp(18), dp(10))
        }
        val brand = TextView(this).apply {
            text = "★ HSSTAR"; textSize = 25f; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        }
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button("ADMIN") { if (adminToken == null) showAdminLogin() else showAdminPanel() })
        root.addView(header)

        val scroll = ScrollView(this).apply { isFillViewport = true; isVerticalScrollBarEnabled = false }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, dp(16), dp(24)) }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun render() {
        content.removeAllViews()
        val hero = FrameLayout(this).apply {
            background = rounded(PANEL, 18)
            clipToOutline = true
        }
        val banner = ImageView(this).apply {
            setImageResource(R.drawable.hsstar_banner); scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.9f
        }
        hero.addView(banner, FrameLayout.LayoutParams(-1, -1))
        val shade = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0x22000000, 0xEE050A18.toInt()))
        }
        hero.addView(shade, FrameLayout.LayoutParams(-1, -1))
        val heroText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.BOTTOM
            setPadding(dp(18), dp(18), dp(18), dp(16))
        }
        heroText.addView(label("HSSTAR ORIGINALS", 11f, GOLD, true))
        heroText.addView(label("Your entertainment,", 23f, Color.WHITE, true))
        heroText.addView(label("your way.", 23f, Color.WHITE, true))
        heroText.addView(label("Movies  •  Series  •  More", 12f, 0xFFE0E8F7.toInt(), false).apply { setPadding(0, dp(5), 0, dp(10)) })
        heroText.addView(button("EXPLORE NOW  ›") { scrollToSection("Trending Now") })
        hero.addView(heroText, FrameLayout.LayoutParams(-1, -1))
        content.addView(hero, LinearLayout.LayoutParams(-1, dp(205)).apply { bottomMargin = dp(16) })

        val search = EditText(this).apply {
            hint = "Search movies, shows and more"; textSize = 14f
            setTextColor(Color.WHITE); setHintTextColor(MUTED); isSingleLine = true
            setPadding(dp(15), dp(10), dp(15), dp(10)); background = rounded(PANEL, 12)
            setText(searchQuery)
            setOnEditorActionListener { v, _, _ -> searchQuery = v.text.toString().trim(); render(); true }
        }
        content.addView(search, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(14) })

        val categories = listOf("All", "Movies", "Web Series", "Short Films", "Other")
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        categories.forEach { category ->
            val chip = TextView(this).apply {
                text = category; textSize = 12f
                setTextColor(if (selectedCategory == category) Color.WHITE else MUTED)
                setPadding(dp(13), dp(9), dp(13), dp(9))
                background = rounded(if (selectedCategory == category) BLUE else PANEL, 30)
                setOnClickListener { selectedCategory = category; render() }
            }
            chips.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
        }
        content.addView(horizontalScroll(chips), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        val filtered = mutableListOf<JSONObject>()
        for (i in 0 until allVideos.length()) {
            val item = allVideos.optJSONObject(i) ?: continue
            val category = item.optString("category", "Other")
            val matchesCategory = selectedCategory == "All" || category.equals(selectedCategory, true)
            val q = searchQuery.lowercase()
            val matchesSearch = q.isBlank() || item.optString("title").lowercase().contains(q) ||
                item.optString("description").lowercase().contains(q) || category.lowercase().contains(q)
            if (matchesCategory && matchesSearch) filtered.add(item)
        }

        if (searchQuery.isNotBlank()) {
            sectionTitle("Search results")
            addPosterRow(filtered)
            if (filtered.isEmpty()) content.addView(emptyMessage("No titles match your search."))
        } else {
            val recent = recentVideos()
            if (recent.isNotEmpty()) {
                sectionTitle("Continue Watching")
                addPosterRow(recent)
            }
            sectionTitle("Trending Now")
            addPosterRow(filtered.take(10))
            sectionTitle("Top 10 on HSSTAR")
            addTopTen(filtered.take(10))
            sectionTitle("Latest Movies & Shows")
            addPosterRow(filtered)
            if (filtered.isEmpty()) content.addView(emptyMessage("No videos published yet. Sign in to the Admin panel to upload your first title."))
        }
        val footer = label("HSSTAR  •  Your entertainment space", 11f, MUTED, false)
        footer.gravity = Gravity.CENTER; footer.setPadding(0, dp(28), 0, dp(10))
        content.addView(footer)
    }

    private fun addPosterRow(items: List<JSONObject>) {
        if (items.isEmpty()) return
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        items.forEach { item -> row.addView(posterCard(item), LinearLayout.LayoutParams(dp(132), -2).apply { rightMargin = dp(10) }) }
        content.addView(horizontalScroll(row), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
    }

    private fun posterCard(item: JSONObject): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = rounded(PANEL, 12); clipToOutline = true
            setOnClickListener { playVideo(item) }
        }
        val image = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(0xFF202B43.toInt()) }
        card.addView(image, LinearLayout.LayoutParams(-1, dp(174)))
        val title = label(item.optString("title", "Untitled"), 13f, Color.WHITE, true)
        title.maxLines = 2; title.setPadding(dp(9), dp(8), dp(9), dp(2))
        card.addView(title)
        val meta = label(item.optString("category", "Entertainment"), 10f, MUTED, false)
        meta.setPadding(dp(9), 0, dp(9), dp(9)); card.addView(meta)
        loadImage(item.optString("thumbnail_url"), image)
        return card
    }

    private fun addTopTen(items: List<JSONObject>) {
        if (items.isEmpty()) return
        items.forEachIndexed { index, item ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = rounded(PANEL, 12); setPadding(dp(10), dp(7), dp(10), dp(7))
                setOnClickListener { playVideo(item) }
            }
            line.addView(label("${index + 1}", 28f, GOLD, true), LinearLayout.LayoutParams(dp(38), -2))
            val thumb = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(0xFF26334D.toInt()) }
            line.addView(thumb, LinearLayout.LayoutParams(dp(62), dp(66)))
            loadImage(item.optString("thumbnail_url"), thumb)
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
            info.addView(label(item.optString("title"), 14f, Color.WHITE, true))
            info.addView(label(item.optString("category", "Entertainment"), 11f, MUTED, false).apply { setPadding(0, dp(4), 0, 0) })
            line.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            line.addView(label("▶", 18f, Color.WHITE, true))
            content.addView(line, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
    }

    private fun playVideo(item: JSONObject) {
        val url = item.optString("video_url")
        if (!url.startsWith("https://")) { toast("Video URL is not available"); return }
        saveRecent(item)
        val videoId = item.optString("id")
        val resumeAt = getSharedPreferences("hsstar_watch", MODE_PRIVATE).getLong("position_$videoId", 0L)
        startActivity(Intent(this, PlayerActivity::class.java)
            .putExtra("video_url", url).putExtra("title", item.optString("title"))
            .putExtra("video_id", videoId).putExtra("resume_position", resumeAt))
    }

    private fun saveRecent(item: JSONObject) {
        val prefs = getSharedPreferences("hsstar_watch", MODE_PRIVATE)
        val arr = JSONArray()
        val id = item.optString("id")
        for (old in recentVideos()) if (old.optString("id") != id) arr.put(old)
        arr.put(0, item)
        val trimmed = JSONArray()
        for (i in 0 until minOf(arr.length(), 12)) trimmed.put(arr.getJSONObject(i))
        prefs.edit().putString("recent", trimmed.toString()).apply()
    }

    private fun recentVideos(): List<JSONObject> {
        val raw = getSharedPreferences("hsstar_watch", MODE_PRIVATE).getString("recent", "[]") ?: "[]"
        val arr = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        val result = mutableListOf<JSONObject>()
        for (i in 0 until arr.length()) {
            val saved = arr.optJSONObject(i) ?: continue
            for (j in 0 until allVideos.length()) {
                val live = allVideos.optJSONObject(j) ?: continue
                if (live.optString("id") == saved.optString("id")) { result.add(live); break }
            }
        }
        return result
    }

    private fun loadImage(url: String, target: ImageView) {
        if (!url.startsWith("https://")) return
        io.execute {
            try {
                val bitmap = URL(url).openStream().use { BitmapFactory.decodeStream(it) }
                if (bitmap != null) runOnUiThread { target.setImageBitmap(bitmap) }
            } catch (_: Exception) { }
        }
    }

    private fun loadVideos() {
        val request = Request.Builder()
            .url(BuildConfig.SUPABASE_URL.trimEnd('/') + "/rest/v1/videos?select=id,title,category,description,video_url,thumbnail_url,is_published,created_at&is_published=eq.true&order=created_at.desc")
            .header("apikey", BuildConfig.SUPABASE_ANON_KEY).build()
        io.execute {
            try {
                http.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) throw IOException("Supabase error ${response.code}: ${response.body?.string()}")
                    val result = JSONArray(response.body?.string().orEmpty())
                    runOnUiThread { allVideos = result; render() }
                }
            } catch (e: Exception) { runOnUiThread { render(); toast("Could not load videos. Check Supabase setup and internet.") } }
        }
    }

    private fun showAdminLogin() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val email = EditText(this).apply { hint = "Admin email"; inputType = 33; setTextColor(Color.WHITE); setHintTextColor(MUTED) }
        val password = EditText(this).apply { hint = "Password"; inputType = 129; setTextColor(Color.WHITE); setHintTextColor(MUTED) }
        box.addView(email); box.addView(password)
        val dialog = AlertDialog.Builder(this).setTitle("HSSTAR Admin Login").setView(box).setNegativeButton("Cancel", null).setPositiveButton("Sign in", null).create()
        dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val e = email.text.toString().trim(); val p = password.text.toString()
            if (e.isBlank() || p.isBlank()) { toast("Enter email and password"); return@setOnClickListener }
            dialog.dismiss(); signInAdmin(e, p)
        } }
        dialog.show()
    }

    private fun signInAdmin(email: String, password: String) {
        io.execute {
            try {
                val body = JSONObject().put("email", email).put("password", password).toString().toRequestBody("application/json".toMediaType())
                val req = Request.Builder().url(BuildConfig.SUPABASE_URL.trimEnd('/') + "/auth/v1/token?grant_type=password")
                    .header("apikey", BuildConfig.SUPABASE_ANON_KEY).post(body).build()
                http.newCall(req).execute().use { response ->
                    val raw = response.body?.string().orEmpty()
                    if (!response.isSuccessful) throw IOException("Login failed: ${try { JSONObject(raw).optString("msg", JSONObject(raw).optString("message", "Check credentials")) } catch (_: Exception) { "Check credentials" }}")
                    val token = JSONObject(raw).getString("access_token")
                    val encodedEmail = java.net.URLEncoder.encode(email.trim().lowercase(), "UTF-8")
                    val verify = Request.Builder().url(BuildConfig.SUPABASE_URL.trimEnd('/') + "/rest/v1/admin_users?select=email&email=eq.$encodedEmail&limit=1")
                        .header("apikey", BuildConfig.SUPABASE_ANON_KEY)
                        .header("Authorization", "Bearer $token")
                        .get().build()
                    http.newCall(verify).execute().use { check ->
                        val checkBody = check.body?.string().orEmpty()
                        if (!check.isSuccessful) {
                            throw IOException("Admin check failed (HTTP ${check.code}). Supabase response: ${checkBody.take(500)}")
                        }
                        val rows = try { JSONArray(checkBody) } catch (_: Exception) { JSONArray() }
                        if (rows.length() == 0) {
                            throw IOException("Login successful, but Supabase did not return an admin_users row for ${email.trim()}. Check the exact email and admin_users SELECT policy.")
                        }
                    }
                    adminToken = token
                }
                runOnUiThread { showAdminPanel() }
            } catch (e: Exception) { runOnUiThread { toast(e.message ?: "Admin login failed") } }
        }
    }

    private fun showAdminPanel() {
        val published = allVideos.length()
        AlertDialog.Builder(this).setTitle("HSSTAR • Admin Dashboard")
            .setMessage("Admin session active\nPublished titles loaded: $published\n\nManage your catalogue, publish or hide titles, and upload new MP4 videos.")
            .setPositiveButton("Upload new video") { _, _ ->
                val pick = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "video/mp4" }
                startActivityForResult(pick, 410)
            }
            .setNeutralButton("Manage catalogue") { _, _ -> showManageVideos() }
            .setNegativeButton("Sign out") { _, _ -> adminToken = null; toast("Signed out") }
            .show()
    }

    private fun showManageVideos() {
        val token = adminToken ?: run { toast("Please sign in again"); return }
        toast("Loading admin catalogue…")
        val req = Request.Builder().url(BuildConfig.SUPABASE_URL.trimEnd('/') + "/rest/v1/videos?select=id,title,category,is_published&order=created_at.desc")
            .header("apikey", BuildConfig.SUPABASE_ANON_KEY).header("Authorization", "Bearer $token").get().build()
        io.execute {
            try {
                http.newCall(req).execute().use { response ->
                    if (!response.isSuccessful) throw IOException("Could not load admin catalogue (${response.code}): ${response.body?.string()}")
                    val arr = JSONArray(response.body?.string().orEmpty())
                    val items = mutableListOf<JSONObject>()
                    for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { items.add(it) }
                    runOnUiThread {
                        if (items.isEmpty()) { toast("No catalogue titles yet"); return@runOnUiThread }
                        val labels = items.map { "${it.optString("title")}  •  ${it.optString("category")}  •  ${if (it.optBoolean("is_published")) "Published" else "Hidden"}" }.toTypedArray()
                        AlertDialog.Builder(this).setTitle("Manage catalogue")
                            .setItems(labels) { _, which -> showVideoActions(items[which]) }
                            .setNegativeButton("Close", null).show()
                    }
                }
            } catch (e: Exception) { runOnUiThread { toast(e.message ?: "Could not load catalogue") } }
        }
    }

    private fun showVideoActions(item: JSONObject) {
        val id = item.optString("id")
        val isPublished = item.optBoolean("is_published", true)
        val visibilityAction = if (isPublished) "Hide from public catalogue" else "Publish to public catalogue"
        AlertDialog.Builder(this).setTitle(item.optString("title"))
            .setItems(arrayOf(visibilityAction, "Delete video record")) { _, which ->
                if (which == 0) updateVideoVisibility(id, !isPublished) else confirmDeleteVideo(id, item.optString("title"))
            }.setNegativeButton("Cancel", null).show()
    }

    private fun confirmDeleteVideo(id: String, title: String) {
        AlertDialog.Builder(this).setTitle("Delete title?").setMessage("Delete '$title' from the catalogue? The stored MP4 file may remain in Storage.")
            .setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ -> deleteVideoRecord(id) }.show()
    }

    private fun updateVideoVisibility(id: String, published: Boolean) {
        val token = adminToken ?: return
        val req = Request.Builder().url(BuildConfig.SUPABASE_URL.trimEnd('/') + "/rest/v1/videos?id=eq.$id")
            .header("apikey", BuildConfig.SUPABASE_ANON_KEY).header("Authorization", "Bearer $token")
            .header("Content-Type", "application/json").header("Prefer", "return=minimal")
            .patch(JSONObject().put("is_published", published).toString().toRequestBody("application/json".toMediaType())).build()
        executeAdminChange(req, "Title hidden from public catalogue")
    }

    private fun deleteVideoRecord(id: String) {
        val token = adminToken ?: return
        val req = Request.Builder().url(BuildConfig.SUPABASE_URL.trimEnd('/') + "/rest/v1/videos?id=eq.$id")
            .header("apikey", BuildConfig.SUPABASE_ANON_KEY).header("Authorization", "Bearer $token").delete().build()
        executeAdminChange(req, "Video record deleted. Storage file may need manual cleanup.")
    }

    private fun executeAdminChange(req: Request, success: String) {
        io.execute {
            try {
                http.newCall(req).execute().use { if (!it.isSuccessful) throw IOException("Admin action failed (${it.code}): ${it.body?.string()}") }
                runOnUiThread { toast(success); loadVideos() }
            } catch (e: Exception) { runOnUiThread { toast(e.message ?: "Admin action failed") } }
        }
    }

    @Deprecated("Use Activity Result API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 410 && resultCode == RESULT_OK) {
            pendingVideoUri = data?.data
            if (pendingVideoUri != null) showVideoDetails()
        }
    }

    private fun showVideoDetails() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val title = EditText(this).apply { hint = "Video title"; setTextColor(Color.WHITE); setHintTextColor(MUTED) }
        val category = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Movies", "Web Series", "Short Films", "Other")) }
        val description = EditText(this).apply { hint = "Description"; setTextColor(Color.WHITE); setHintTextColor(MUTED) }
        val thumbnail = EditText(this).apply { hint = "Poster image URL (https://...)"; setTextColor(Color.WHITE); setHintTextColor(MUTED) }
        box.addView(title); box.addView(category); box.addView(description); box.addView(thumbnail)
        val dialog = AlertDialog.Builder(this).setTitle("Publish a new title").setView(box).setNegativeButton("Cancel", null).setPositiveButton("Upload", null).create()
        dialog.setOnShowListener { dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            if (title.text.toString().isBlank()) { toast("Enter a title"); return@setOnClickListener }
            val t = title.text.toString().trim(); val c = category.selectedItem.toString()
            val d = description.text.toString().trim(); val image = thumbnail.text.toString().trim()
            if (image.isNotBlank() && !image.startsWith("https://")) { toast("Poster URL must start with https://"); return@setOnClickListener }
            dialog.dismiss(); uploadVideo(pendingVideoUri!!, t, c, d, image)
        } }
        dialog.show()
    }

    private fun uploadVideo(uri: Uri, title: String, category: String, description: String, thumbnail: String) {
        val token = adminToken ?: run { toast("Please sign in again"); return }
        toast("Upload started. Keep the app open until it finishes.")
        io.execute {
            try {
                val name = "${UUID.randomUUID()}.mp4"
                val objectUrl = BuildConfig.SUPABASE_URL.trimEnd('/') + "/storage/v1/object/hsstar-videos/$name"
                val requestBody = object : RequestBody() {
                    override fun contentType() = "video/mp4".toMediaType()
                    override fun contentLength(): Long = contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
                    override fun writeTo(sink: BufferedSink) {
                        contentResolver.openInputStream(uri).use { input ->
                            requireNotNull(input) { "Cannot open selected video" }
                            val buffer = ByteArray(64 * 1024)
                            while (true) { val count = input.read(buffer); if (count == -1) break; sink.write(buffer, 0, count) }
                        }
                    }
                }
                val uploadReq = Request.Builder().url(objectUrl).header("apikey", BuildConfig.SUPABASE_ANON_KEY)
                    .header("Authorization", "Bearer $token").header("x-upsert", "false").put(requestBody).build()
                http.newCall(uploadReq).execute().use { response -> if (!response.isSuccessful) throw IOException("Storage upload failed (${response.code}): ${response.body?.string()}") }
                val publicUrl = BuildConfig.SUPABASE_URL.trimEnd('/') + "/storage/v1/object/public/hsstar-videos/$name"
                val row = JSONObject().put("title", title).put("category", category).put("description", description)
                    .put("video_url", publicUrl).put("thumbnail_url", thumbnail.ifBlank { JSONObject.NULL }).put("is_published", true)
                val insertReq = Request.Builder().url(BuildConfig.SUPABASE_URL.trimEnd('/') + "/rest/v1/videos")
                    .header("apikey", BuildConfig.SUPABASE_ANON_KEY).header("Authorization", "Bearer $token")
                    .header("Content-Type", "application/json").header("Prefer", "return=minimal")
                    .post(row.toString().toRequestBody("application/json".toMediaType())).build()
                http.newCall(insertReq).execute().use { response -> if (!response.isSuccessful) throw IOException("Video uploaded but database save failed (${response.code}): ${response.body?.string()}") }
                runOnUiThread { toast("Video published successfully"); loadVideos() }
            } catch (e: Exception) { runOnUiThread { toast(e.message ?: "Upload failed") } }
        }
    }

    private fun sectionTitle(text: String) {
        content.addView(label(text, 19f, Color.WHITE, true).apply { setPadding(0, dp(13), 0, dp(10)) })
    }
    private fun emptyMessage(text: String) = label(text, 13f, MUTED, false).apply { setPadding(dp(10), dp(16), dp(10), dp(18)) }
    private fun horizontalScroll(child: View) = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(child) }
    private fun scrollToSection(title: String) { content.post { (content.parent as? ScrollView)?.smoothScrollTo(0, dp(260)) } }
    private fun label(text: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }
    private fun button(text: String, action: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
        setPadding(dp(15), dp(10), dp(15), dp(10)); background = rounded(BLUE, 22); setOnClickListener { action() }
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
